// Initialize Firebase
var config = {
        apiKey: "AIzaSyBOczxurryKMx5EnCOemQhRwYDtA7zyM-I",
        authDomain: "tutorwebsite-83af1.firebaseapp.com",
        databaseURL: "https://tutorwebsite-83af1.firebaseio.com",
        projectId: "tutorwebsite-83af1",
        storageBucket: "tutorwebsite-83af1.appspot.com",
        messagingSenderId: "316383180226"
      };

function initFireB() {
  firebase.initializeApp(config);
  var database = firebase.database().ref();
  displayQuestions(database)
  }

var data;

// DISPLAY QUESTIONS
function displayQuestions(database) {
  database.child("ProjectQuestion").on('value', function(snapshot) {
    data = snapshot.val();
    var template = $("#Test").html();
    var build = "";
    var qNumber = 0; // Question number

    for (var key in data) {
      qNumber++;
      quesJSON = {
        "data": data[key],
        "qID": key,
        "qNum": qNumber
      }
      build += Mustache.render(template, quesJSON);
    }
    $("#quiz").html(build);
  });
}

// CHECK ANSWERS AND CALCULATE SCORE
function checkAnswers() {
  var grade = 0;

  for (var key in data) {
    var userAns = $(key).val();
    console.log(userAns);
    var correctAns = data[key].answer;

    if (userAns.toUpperCase() == correctAns.toUpperCase()) {
      grade += 1;
    }
  }
  //console.log(grade);
  $("#score").html("<h1>Your score: " + grade + " points</h1>");
}