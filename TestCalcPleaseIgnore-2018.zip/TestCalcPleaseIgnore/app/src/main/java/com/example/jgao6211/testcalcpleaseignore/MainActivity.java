package com.example.jgao6211.testcalcpleaseignore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView display;String out;Button div;Button mult;boolean radMode = true;
    public MainActivity() {
        out = "";
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //Parameters
    public void setTrigMode(View v){
        if(radMode){
            radMode=false;
        }else{
            radMode=true;
        }
    }
    //Set Numbers
    public void dis0(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "0";
        display.setText(out);
    }
    public void dis1(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "1";
        display.setText(out);
    }
    public void dis2(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "2";
        display.setText(out);
    }
    public void dis3(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "3";
        display.setText(out);
    }
    public void dis4(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "4";
        display.setText(out);
    }
    public void dis5(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "5";
        display.setText(out);
    }
    public void dis6(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "6";
        display.setText(out);
    }
    public void dis7(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "7";
        display.setText(out);
    }
    public void dis8(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "8";
        display.setText(out);
    }
    public void dis9(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(true);
        div.setClickable(true);
        out += "9";
        display.setText(out);
    }
    public void disDot(View v) {
        display = findViewById(R.id.display);
        out += ".";
        display.setText(out);
    }
    public void disI(View v){
        display = findViewById(R.id.display);
        out += "i";
        display.setText(out);
    }
    //Set Operators
    public void disFactorial(View v){
        display = findViewById(R.id.display);
        out += "!";
        display.setText(out);
    }
    public void disPO(View v) {
        display = findViewById(R.id.display);
        out += "(";
        display.setText(out);
    }
    public void disPC(View v) {
        display = findViewById(R.id.display);
        out += ")";
        display.setText(out);
    }
    public void disExp(View v) {
        display = findViewById(R.id.display);
        out += "^";
        display.setText(out);
    }
    public void disSin(View v) {
        display = findViewById(R.id.display);
        out += "sin(";
        display.setText(out);
    }
    public void disCos(View v) {
        display = findViewById(R.id.display);
        out += "cos(";
        display.setText(out);
    }
    public void disTan(View v) {
        display = findViewById(R.id.display);
        out += "tan(";
        display.setText(out);
    }
    public void div(View v) {
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(false);
        div.setClickable(false);
        out = out + "/";
        display.setText(out);
    }
    public void mult(View v) {
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(false);
        div.setClickable(false);
        out = out + "x";
        display.setText(out);
    }
    public void plus(View v) {
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(false);
        div.setClickable(false);
        out = out + "+";

        display.setText(out);
    }
    public void minus(View v) {
        display = findViewById(R.id.display);
        div = findViewById(R.id.buttonDiv);
        mult = findViewById(R.id.buttonX);
        mult.setClickable(false);
        div.setClickable(false);
        out = out + "-";
        display.setText(out);
    }
    public void del(View v) {
        display = findViewById(R.id.display);
        mult = findViewById(R.id.buttonX);
        div = findViewById(R.id.buttonDiv);
        out = out.substring(0, out.length() - 1);
        display.setText(out);
        if (!mult.isClickable()) {
            mult.setClickable(true);
        } else if (!div.isClickable()) {
            div.setClickable(true);
        }
    }
    public void clear(View v) {
        display = findViewById(R.id.display);
        mult = findViewById(R.id.buttonX);
        div = findViewById(R.id.buttonDiv);
        out = "";
        display.setText(out);
        if (!mult.isClickable()) {
            mult.setClickable(true);
        } else if (!div.isClickable()) {
            div.setClickable(true);
        }
    }
    public void solve(View v) {
        int pCount = 0, pTest = 0;
        out=conNeg(out);out=calcFactorial(out);out = conTrig(out);
        for (int i = 0; i < out.length(); i++) {
            if (out.substring(i, i + 1).equals("(")) {pCount++;}
        }
        for (int i = 0; i < out.length(); i++) {
            if (out.substring(i, i + 1).equals(")")) {pTest++;}
        }
        out = calcTrig(out);
        if (out.contains("/0")) {out = "divideByZeroError";}
        else if (pCount != pTest) {out = "syntaxError";}
        else {
            if (pCount != 0) {
                for (int q = 0; q < out.length() - 2; q++) {
                    if (out.substring(q, q + 2).equals(")(")) {
                        out = out.substring(0, q) + ")x(" + out.substring(q + 2);
                        q--;
                    }
                }
                for (int asd = 0; asd <= pCount; asd++) {
                    boolean flag = true;
                    int posPo = 0, posPc = out.length();
                    for (int i = 0; i < out.length(); i++) {//find innermost parentheses
                        if (out.substring(i, i + 1).equals("(")) {
                            posPo = i;
                        }
                    }
                    for (int x = posPo; (x < out.length()) && flag; x++) {
                        if (out.substring(x, x + 1).equals(")")) {
                            posPc = x;
                            flag = false;
                        }
                    }

                    if (out.substring(out.length() - 1, out.length()).equals(")")) {
                        out = out.substring(0, posPo) + subsolve(posPo + 1, posPc);
                        pCount--;
                    } else {
                        out = out.substring(0, posPo) + subsolve(posPo + 1, posPc) + out.substring(posPc + 1);
                        pCount--;
                    }
                }
            } else {
                out = subsolve(0, out.length());
            }
            out = subsolve(0, out.length());
        }
        try {if (out.substring(out.length()-2).equals(".0")) {out = out.substring(0,out.indexOf("."));}}catch (Exception foo){}
        if(out.substring(0,1).equals("n")){out="-"+out.substring(1);}
        display.setText(out);
    }
    public int f(int x){
        if (x==0){
            return 1;
        }else{
            return x * f(x-1);
        }
    }
    public String calcFactorial(String q){
        int posLastOP=0;boolean flag1=true,flag2=true;int a,b=1;
        for(int i=0;i<q.length();i++) {
            if (q.substring(i, i + 1).equals("!")) {
                for (int x = i - 1; x >= 0 && flag1; x--) {
                    if (q.substring(x, x + 1).equals("x") || q.substring(x, x + 1).equals("/") || q.substring(x, x + 1).equals("+") || q.substring(x, x + 1).equals("-") || q.substring(x, x + 1).equals("^")) {posLastOP = x;flag1 = false;}
                    else if (x == 0) {posLastOP = -1;flag1 = false;}
                }
                if (q.substring(posLastOP+1,posLastOP+2).equals("n")) {
                    return "domainError";
                }else if(q.contains(".")){
                    return "syntaxError";
                }else{
                    a=Integer.parseInt(q.substring(posLastOP+1, i));
                    b=f(a);
                }
                q=q.substring(0,posLastOP+1)+b+q.substring(i+1);
            }
        }
        return q;
    }
    public String calcTrig(String q) {
        for (int z = 0; z < q.length() - 5; z++) {
            if (radMode) {
                boolean flag = true;
                int a = q.length();
                if (q.substring(z, z + 4).equals("sin[")) {
                    for (int i = 0; i < q.length() && flag; i++) {
                        if (q.substring(i, i + 1).equals("]")) {
                            a = i;
                            flag = false;
                        }
                    }
                    q = q.substring(0, z) + Math.sin(Double.parseDouble(q.substring(z + 4, a))) + q.substring(a + 1);
                } else if (q.substring(z, z + 4).equals("cos[")) {
                    for (int i = 0; i < q.length() && flag; i++) {
                        if (q.substring(i, i + 1).equals("]")) {
                            a = i;
                            flag = false;
                        }
                    }
                    q = q.substring(0, z) + Math.cos(Double.parseDouble(q.substring(z + 4, a))) + q.substring(a + 1);
                } else if (q.substring(z, z + 4).equals("tan[")) {
                    for (int i = 0; i < q.length() && flag; i++) {
                        if (q.substring(i, i + 1).equals("]")) {
                            a = i;
                            flag = false;
                        }
                    }
                    q = q.substring(0, z) + Math.tan(Double.parseDouble(q.substring(z + 4, a))) + q.substring(a + 1);
                }
            } else {
                boolean flag = true;double Pi=3.14159265358979323846264338327950288419716939937510582097494459230781640628620899862803482534211706798214808651328230664709384460955058223172535940812848111745028410270193852110555964462294895493038196442881097566593344612847564823378678316527120190914564856692346034861045432664821339360726024914127372458700660631558817488152092096282925409171536436789259036001133053054882046652138414695194151160943305727036575959195309218611738193261179310511854807446237996274956735188575272489122793818301194912983367336244065664308602139494639522473719070217986094370277053921717629317675238467481846766940513200056812714526356082778577134275778960917363717872146844090122495343014654958537105079227968925892354201995611212902196086403441815981362977477130996051870721134999999837297804995105973173281609631859502445945534690830264252230825334468503526193118817101000313783875288658753320838142061717766914730359825349042875546873115956286388235378759375195778185778053217122680661300192787661119590921642019;
                int a = q.length();
                if (q.substring(z, z + 4).equals("sin[")) {
                    for (int i = 0; i < q.length() && flag; i++) {
                        if (q.substring(i, i + 1).equals("]")) {
                            a = i;
                            flag = false;
                        }
                    }
                    q = q.substring(0, z) + Math.sin(Double.parseDouble(q.substring(z + 4, a))*Pi/180) + q.substring(a + 1);
                } else if (q.substring(z, z + 4).equals("cos[")) {
                    for (int i = 0; i < q.length() && flag; i++) {
                        if (q.substring(i, i + 1).equals("]")) {
                            a = i;
                            flag = false;
                        }
                    }
                    q = q.substring(0, z) + Math.cos(Double.parseDouble(q.substring(z + 4, a))*Pi/180) + q.substring(a + 1);
                } else if (q.substring(z, z + 4).equals("tan[")) {
                    for (int i = 0; i < q.length() && flag; i++) {
                        if (q.substring(i, i + 1).equals("]")) {
                            a = i;
                            flag = false;
                        }
                    }
                    q = q.substring(0, z) + Math.tan(Double.parseDouble(q.substring(z + 4, a))*Pi/180) + q.substring(a + 1);
                }
            }
        }
        if(q.substring(0,1).equals("-")){
            q="n"+q.substring(1);
        }
        return q;
    }
    public String conTrig(String q) {
        for (int z = 0; z < q.length(); z++) {
            int a = 0, b = q.length(), i;
            if (q.contains("sin(")) {
                for (i = q.indexOf("sin") + 4; (i < q.length()) && (a != -1); i++) {
                    if (q.substring(i, i + 1).equals("(")) {
                        a++;
                    } else if (q.substring(i, i + 1).equals(")")) {
                        a--;
                    }
                }
                q = q.substring(0, q.indexOf("sin(")) + "sin[" + q.substring(q.indexOf("sin(") + 4, i - 1) + "]" + q.substring(i);
            } else if (q.contains("cos(")) {
                for (i = q.indexOf("cos") + 4; (i < q.length()) && (a != -1); i++) {
                    if (q.substring(i, i + 1).equals("(")) {
                        a++;
                    } else if (q.substring(i, i + 1).equals(")")) {
                        a--;
                    }
                }
                q = q.substring(0, q.indexOf("cos(")) + "cos[" + q.substring(q.indexOf("cos(") + 4, i - 1) + "]" + q.substring(i);
            } else if (q.contains("tan(")) {
                for (i = q.indexOf("tan") + 4; (i < q.length()) && (a != -1); i++) {
                    if (q.substring(i, i + 1).equals("(")) {
                        a++;
                    } else if (q.substring(i, i + 1).equals(")")) {
                        a--;
                    }
                }
                q = q.substring(0, q.indexOf("tan(")) + "tan[" + q.substring(q.indexOf("tan(") + 4, i - 1) + "]" + q.substring(i);
            }
        }
        return q;
    }
    public String conNeg(String q){
        for(int i=0;i<q.length()-1;i++){
            if((q.substring(i,i+1).equals("-")||q.substring(i,i+1).equals("+")||q.substring(i,i+1).equals("x")||q.substring(i,i+1).equals("/")||q.substring(i,i+1).equals("^"))&&q.substring(i+1,i+2).equals("-")){
                q=q.substring(0,i+1)+"n"+q.substring(i+2);
            }else if(i==0&&q.substring(0,1).equals("-")){
                q="n"+q.substring(1);
            }
        }
        return q;
    }
    public String o2(String q) {
        int posLastOP = 0, posNextOP = 0;boolean flag1 = true, flag2 = true;double a, b, c;
        for (int i = 1; i < q.length(); i++) {//Order2 operations
            if (q.substring(i, i + 1).equals("^")) {
                for (int x = i - 1; x >= 0 && flag1; x--) {
                    if (q.substring(x, x + 1).equals("x") || q.substring(x, x + 1).equals("/") || q.substring(x, x + 1).equals("+") || q.substring(x, x + 1).equals("-") || q.substring(x, x + 1).equals("^")) {
                        posLastOP = x;flag1 = false;
                    } else if (x == 0) {
                        posLastOP = -1;flag1 = false;
                    }
                }
                for (int y = i + 1; y < q.length() && flag2; y++) {
                    if (q.substring(y, y + 1).equals("x") || q.substring(y, y + 1).equals("/") || q.substring(y, y + 1).equals("+") || q.substring(y, y + 1).equals("-") || q.substring(y, y + 1).equals("^")) {
                        posNextOP = y;flag2 = false;
                    } else if (y == q.length() - 1) {
                        posNextOP = q.length();flag2 = false;
                    }
                }

                if(q.substring(posLastOP + 1, posLastOP + 2).equals("n")){b = -1*Double.parseDouble(q.substring(posLastOP + 2, i));}else {b = Double.parseDouble(q.substring(posLastOP + 1, i));}
                if(q.substring(i + 1, i + 2).equals("n")){
                    c = -1*Double.parseDouble(q.substring(i + 2, posNextOP));
                }
                else {c = Double.parseDouble(q.substring(i + 1, posNextOP));}
                a = Math.pow(b, c);
                if(a>=0){q = q.substring(0, posLastOP + 1) + a + q.substring(posNextOP);}else{q = q.substring(0, posLastOP + 1) + "n" + ((-1)*a) + q.substring(posNextOP);}
                i--;flag2 = true;flag1 = true;
            }
        }
        return q;
    }
    public String o3(String q) {
        int posLastOP = 0, posNextOP = 0;boolean flag1 = true, flag2 = true;double a, b, c;
        for (int i = 1; i < q.length(); i++) {//Order3 operations
            if (q.substring(i, i + 1).equals("x")) {
                for (int x = i - 1; x >= 0 && flag1; x--) {
                    if (q.substring(x, x + 1).equals("x") || q.substring(x, x + 1).equals("/") || q.substring(x, x + 1).equals("+") || q.substring(x, x + 1).equals("-")) {
                        posLastOP = x;flag1 = false;
                    } else if (x == 0) {
                        posLastOP = -1;flag1 = false;
                    }
                }
                for (int y = i + 1; y < q.length() && flag2; y++) {
                    if (q.substring(y, y + 1).equals("x") || q.substring(y, y + 1).equals("/") || q.substring(y, y + 1).equals("+") || q.substring(y, y + 1).equals("-")) {
                        posNextOP = y;flag2 = false;
                    } else if (y == q.length() - 1) {
                        posNextOP = q.length();flag2 = false;
                    }
                }
                if(q.substring(posLastOP + 1, posLastOP + 2).equals("n")){b = -1*Double.parseDouble(q.substring(posLastOP + 2, i));}else{b = Double.parseDouble(q.substring(posLastOP + 1, i));}
                if(q.substring(i + 1, i + 2).equals("n")){c = -1*Double.parseDouble(q.substring(i + 2, posNextOP));}else{c = Double.parseDouble(q.substring(i + 1, posNextOP));}
                a = b * c;
                if(a<0){q = q.substring(0, posLastOP + 1) + "n"+Math.abs(a) + q.substring(posNextOP);}else{q = q.substring(0, posLastOP + 1) + a + q.substring(posNextOP);}
                i--;flag2 = true;flag1 = true;
            } else if (q.substring(i, i + 1).equals("/")) {
                for (int x = i - 1; x >= 0 && flag1; x--) {
                    if (q.substring(x, x + 1).equals("x") || q.substring(x, x + 1).equals("/") || q.substring(x, x + 1).equals("+") || q.substring(x, x + 1).equals("-")) {
                        posLastOP = x;flag1 = false;
                    } else if (x == 0) {
                        posLastOP = -1;flag1 = false;
                    }
                }
                for (int y = i + 1; y < q.length() && flag2; y++) {
                    if (q.substring(y, y + 1).equals("x") || q.substring(y, y + 1).equals("/") || q.substring(y, y + 1).equals("+") || q.substring(y, y + 1).equals("-")) {
                        posNextOP = y;flag2 = false;
                    } else if (y == q.length() - 1) {
                        posNextOP = q.length();flag2 = false;
                    }
                }
                if(q.substring(posLastOP + 1, posLastOP + 2).equals("n")){b = -1*Double.parseDouble(q.substring(posLastOP + 2, i));}else {b = Double.parseDouble(q.substring(posLastOP + 1, i));}
                if(q.substring(i + 1, i + 2).equals("n")){c = -1*Double.parseDouble(q.substring(i + 2, posNextOP));}else {c = Double.parseDouble(q.substring(i + 1, posNextOP));}
                a = b / c;
                if(a<0){q = q.substring(0, posLastOP + 1) + "n"+Math.abs(a) + q.substring(posNextOP);}else{q = q.substring(0, posLastOP + 1) + a + q.substring(posNextOP);}
                i--;flag2 = true;flag1 = true;
            }
        }
        return q;
    }
    public String o4(String q) {
        int posLastOP = 0, posNextOP = 0;boolean flag1 = true, flag2 = true;double a, b, c;
        for (int i = 1; i < q.length(); i++) {//Order4 operations
            if (q.substring(i, i + 1).equals("+")) {
                for (int x = i - 1; x >= 0 && flag1; x--) {
                    if (q.substring(x, x + 1).equals("x") || q.substring(x, x + 1).equals("/") || q.substring(x, x + 1).equals("+") || q.substring(x, x + 1).equals("-")) {
                        posLastOP = x;flag1 = false;
                    } else if (x == 0) {
                        posLastOP = -1;flag1 = false;
                    }
                }
                for (int y = i + 1; y < q.length() && flag2; y++) {
                    if (q.substring(y, y + 1).equals("x") || q.substring(y, y + 1).equals("/") || q.substring(y, y + 1).equals("+") || q.substring(y, y + 1).equals("-")) {
                        posNextOP = y;flag2 = false;
                    } else if (y == q.length() - 1) {
                        posNextOP = q.length();flag2 = false;
                    }
                }
                if(q.substring(posLastOP + 1, posLastOP + 2).equals("n")){
                    b = -1*Double.parseDouble(q.substring(posLastOP + 2, i));
                }else {
                    b = Double.parseDouble(q.substring(posLastOP + 1, i));
                }
                if(q.substring(i + 1, i + 2).equals("n")){
                    c = -1*Double.parseDouble(q.substring(i + 2, posNextOP));
                }else {
                    c = Double.parseDouble(q.substring(i + 1, posNextOP));
                }
                a = b + c;
                if(a<0){q = q.substring(0, posLastOP + 1) + "n"+Math.abs(a) + q.substring(posNextOP);}else{q = q.substring(0, posLastOP + 1) + a + q.substring(posNextOP);}
                i--;flag2 = true;flag1 = true;
            } else if (q.substring(i, i + 1).equals("-")) {
                for (int x = i - 1; x >= 0 && flag1; x--) {
                    if (q.substring(x, x + 1).equals("x") || q.substring(x, x + 1).equals("/") || q.substring(x, x + 1).equals("+") || q.substring(x, x + 1).equals("-")) {
                        posLastOP = x;flag1 = false;
                    } else if (x == 0) {
                        posLastOP = -1;flag1 = false;
                    }
                }
                for (int y = i + 1; y < q.length() && flag2; y++) {
                    if (q.substring(y, y + 1).equals("x") || q.substring(y, y + 1).equals("/") || q.substring(y, y + 1).equals("+") || q.substring(y, y + 1).equals("-")) {
                        posNextOP = y;flag2 = false;
                    } else if (y == q.length() - 1) {
                        posNextOP = q.length();flag2 = false;
                    }

                }
                if(q.substring(posLastOP + 1, posLastOP + 2).equals("n")){b = -1*Double.parseDouble(q.substring(posLastOP + 2, i));}else {b = Double.parseDouble(q.substring(posLastOP + 1, i));}
                if(q.substring(i + 1, i + 2).equals("n")){c = -1*Double.parseDouble(q.substring(i + 2, posNextOP));}else {c = Double.parseDouble(q.substring(i + 1, posNextOP));}
                a = b - c;
                if(a<0){q = q.substring(0, posLastOP + 1) + "n"+Math.abs(a) + q.substring(posNextOP);}else{q = q.substring(0, posLastOP + 1) + a + q.substring(posNextOP);}
                i--;flag2 = true;flag1 = true;
            }
        }
        return q;
    }
    public String subsolve(int start, int end) {
        String chunk = out.substring(start, end);
        chunk = o2(chunk);
        chunk = o3(chunk);
        chunk = o4(chunk);
        return chunk;
    }
}

