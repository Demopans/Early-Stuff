package com.example.jgao6211.testcalcpleaseignore;

/**
 * Created by jgao6211 on 4/13/2018.
 */

public class I{
    public double real;
    public double imaginary;
    public I(String input) {
        boolean flag=true;int i=1;
        if (input.indexOf("i") == input.length() - 1) {
            for(int x=0;x<input.length()&&flag;x++){
                if(input.substring(x,x+1).equals("+")||input.substring(x,x+1).equals("-")){
                    i=x;flag=false;
                }
            }
            this.real = Double.parseDouble(input.substring(0,i));
            this.imaginary = Double.parseDouble(input.substring(i+1));
        }else{
            for(int x=0;x<input.length()&&flag;x++){
                if(input.substring(x,x+1).equals("+")||input.substring(x,x+1).equals("-")){
                    i=x;flag=false;
                }
            }
            this.imaginary = Double.parseDouble(input.substring(0,i));
            this.real = Double.parseDouble(input.substring(i+1));
        }
    }
    public I multiply(I a){
        double b=this.real*a.real-this.imaginary*a.imaginary;
        double c=this.real*a.imaginary+this.imaginary*a.real;
        return new I(""+b+"+"+c+"i");
    }
    public I divide(I a){
        
        this.multiply();
        return ;
    }
}