package com.example.jgao6211.testcalcpleaseignore;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by jgao6211 on 4/13/2018.
 */
public class ITest {
    @Test
    public void divide() throws Exception {
    a
    }

}