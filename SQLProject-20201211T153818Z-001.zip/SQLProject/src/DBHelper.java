import java.sql.*;
import java.util.Scanner;

public class DBHelper {
    private Connection conn;private String DBurl;
    public DBHelper(String DBurl) throws SQLException {
        this.conn = DriverManager.getConnection(DBurl);
        this.DBurl = DBurl;
    }
    public String getProduct() throws SQLException {
        String sql = "SELECT * FROM products;";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        String build = "";

        while (rs.next()) {
            build += rs.getString("Name") + "\n";
        }
        rs.close();
        stmt.close();
        return build;
    }
    public boolean login() throws SQLException {
        //Retreve U and P
        Statement stmt = conn.createStatement();
        ResultSet logins = stmt.executeQuery("SELECT * FROM customers;");
        ResultSet rowRS = stmt.executeQuery("SELECT COUNT(*) FROM customers");//row count

        ResultSetMetaData getCol = logins.getMetaData();
        int Ccount = getCol.getColumnCount(),Rcount=rowRS.getInt(1);
        String[][] credintals=new String[Rcount][2];
        while (logins.next()) {
            for(int row=1;row<=Rcount;row++){
                credintals[row-1][0]=logins.getString(1);
                credintals[row-1][1]=logins.getString(2);
            }
        }
        //Verily U and P
        boolean isAdmin=false;
        System.out.println("Please login first");
        System.out.println("Username");
        Scanner sc = new Scanner(System.in);
        boolean f1=false,f2=false;
        String u = sc.nextLine();
        for(int i=0;i<credintals.length;i++){
            if(u.equals(credintals[i][0])){
                System.out.println("Password");
                String p = sc.nextLine();
                if(p.equals(credintals[i][1])){
                    isAdmin=true;
                }
            }
        }
        return isAdmin;
    }
    public String getPassword() throws SQLException {
        String sql = "SELECT * FROM customers;";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        String build = "";

        while (rs.next()) {
            build += rs.getString("Name") + "\n";
        }
        rs.close();
        stmt.close();
        return build;
    }
    public void deleteUsers(String email) throws SQLException{
        String sql = "DELETE FROM customers WHERE email LIKE '%"+email+"'";
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(sql);
    }
    public void insertNewCustomer(String F, String L, String C, String S, String E)throws SQLException{
        String sql = String.format("INSERT INTO customers (FirstName, LastName, City, State, Email) " +
                "VALUES ('%s','%s','%s','%s','%s')",F,L,C,S,E);
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(sql);

    }
    public void buyProduct(String oldstate, String newstate)throws SQLException{
        String sql = String.format("UPDATE customers SET State = '%s' WHERE State = '%s'",newstate,oldstate);

        Statement stmt = conn.createStatement();
        stmt.executeUpdate(sql);

    }
}
