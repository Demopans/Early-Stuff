import java.sql.SQLException;
import java.util.Scanner;

public class SQLProgram {

    public static void main(String[] args) throws SQLException {
        Boolean isAdmin=false;int loginAttempts=0;
        DBHelper db = new DBHelper("jdbc:sqlite:gamedb.db");
        Scanner sc = new Scanner(System.in);

        int menuOption = -1;

        while(menuOption != 0){
            System.out.println("Welcome to the Bayside SQL Application");
            System.out.println("Press:\n"+
            "1 - Login\n" +
            "2 - Continue as Guest\n" +
            "0 - Quit");
            System.out.println("Type your choice below");
            menuOption = sc.nextInt();
            sc.nextLine();
            if (menuOption == 1) {
                isAdmin = db.login();
            }else if (menuOption == 2){
                menuOption = -1;
                System.out.println("Press:\n"+
                        "1 - View\n" +
                        "2 - Continue as Guest\n" +
                        "0 - Quit");
            }else if (menuOption == 0){

            }


        }

    }



}